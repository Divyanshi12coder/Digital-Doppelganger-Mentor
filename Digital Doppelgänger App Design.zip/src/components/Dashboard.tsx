import { motion } from 'motion/react';
import { Button } from './ui/button';
import { Card } from './ui/card';
import { Progress } from './ui/progress';
import { ProfileData } from './ProfileSetup';
import { 
  ArrowLeft, 
  TrendingUp, 
  Brain, 
  Clock, 
  Target,
  Zap,
  Heart,
  BookOpen,
  Calendar,
  Award
} from 'lucide-react';

interface DashboardProps {
  profile: ProfileData;
  onBack: () => void;
}

const progressData = [
  { 
    label: 'Productivity', 
    value: 78, 
    color: 'text-cyan-400', 
    bgColor: 'bg-cyan-400',
    icon: TrendingUp 
  },
  { 
    label: 'Mood', 
    value: 85, 
    color: 'text-purple-400', 
    bgColor: 'bg-purple-400',
    icon: Heart 
  },
  { 
    label: 'Focus', 
    value: 92, 
    color: 'text-pink-400', 
    bgColor: 'bg-pink-400',
    icon: Brain 
  },
  { 
    label: 'Energy', 
    value: 67, 
    color: 'text-yellow-400', 
    bgColor: 'bg-yellow-400',
    icon: Zap 
  }
];

const studyStats = [
  { label: 'Hours Today', value: '4.2', unit: 'hrs', icon: Clock },
  { label: 'Streak', value: '12', unit: 'days', icon: Calendar },
  { label: 'Goals Met', value: '8', unit: '/10', icon: Target },
  { label: 'Topics Learned', value: '24', unit: 'total', icon: BookOpen }
];

const predictions = [
  {
    title: "Peak Performance Time",
    prediction: "Tomorrow 2:30 PM - 4:00 PM",
    confidence: 94,
    type: "optimal"
  },
  {
    title: "Skill Mastery ETA",
    prediction: "React Advanced: 18 days",
    confidence: 87,
    type: "learning"
  },
  {
    title: "Burnout Risk",
    prediction: "Low (Next 7 days)",
    confidence: 91,
    type: "warning"
  },
  {
    title: "Goal Achievement",
    prediction: "Monthly target: 89% likely",
    confidence: 89,
    type: "success"
  }
];

export function Dashboard({ profile, onBack }: DashboardProps) {
  return (
    <div className="min-h-screen starry-bg">
      {/* Header */}
      <motion.div
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
        className="glass-panel border-b border-cyan-500/20 p-4"
      >
        <div className="flex items-center justify-between max-w-6xl mx-auto">
          <div className="flex items-center space-x-4">
            <Button
              onClick={onBack}
              className="cyber-button p-2"
              size="sm"
            >
              <ArrowLeft className="w-5 h-5 text-cyan-400" />
            </Button>
            <div>
              <h1 className="text-2xl neon-gradient-text">Shadow Insights</h1>
              <p className="text-cyan-300">Your digital analytics dashboard</p>
            </div>
          </div>
          <div className="flex items-center space-x-3">
            <div className="text-3xl">{profile.avatar}</div>
            <Award className="w-8 h-8 text-yellow-400" />
          </div>
        </div>
      </motion.div>

      <div className="max-w-6xl mx-auto p-6 space-y-8">
        {/* Progress Rings */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
        >
          <h2 className="text-2xl text-white mb-6">Performance Metrics</h2>
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-6">
            {progressData.map((item, index) => {
              const IconComponent = item.icon;
              return (
                <motion.div
                  key={item.label}
                  initial={{ opacity: 0, scale: 0.8 }}
                  animate={{ opacity: 1, scale: 1 }}
                  transition={{ delay: index * 0.1, duration: 0.6 }}
                >
                  <Card className="glass-panel p-6 text-center space-y-4 glow-hover">
                    <div className="relative w-24 h-24 mx-auto">
                      {/* Progress Circle */}
                      <svg className="w-24 h-24 transform -rotate-90" viewBox="0 0 36 36">
                        <path
                          className="text-gray-700"
                          d="M18 2.0845
                            a 15.9155 15.9155 0 0 1 0 31.831
                            a 15.9155 15.9155 0 0 1 0 -31.831"
                          fill="none"
                          stroke="currentColor"
                          strokeWidth="2"
                        />
                        <motion.path
                          className={item.color}
                          d="M18 2.0845
                            a 15.9155 15.9155 0 0 1 0 31.831
                            a 15.9155 15.9155 0 0 1 0 -31.831"
                          fill="none"
                          stroke="currentColor"
                          strokeWidth="2"
                          strokeDasharray={`${item.value}, 100`}
                          initial={{ strokeDasharray: "0, 100" }}
                          animate={{ strokeDasharray: `${item.value}, 100` }}
                          transition={{ duration: 1.5, delay: index * 0.2 }}
                        />
                      </svg>
                      <div className="absolute inset-0 flex items-center justify-center">
                        <IconComponent className={`w-6 h-6 ${item.color}`} />
                      </div>
                    </div>
                    <div>
                      <h3 className="text-lg text-white">{item.label}</h3>
                      <p className={`text-2xl ${item.color}`}>{item.value}%</p>
                    </div>
                  </Card>
                </motion.div>
              );
            })}
          </div>
        </motion.div>

        {/* Study Statistics */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2, duration: 0.8 }}
        >
          <h2 className="text-2xl text-white mb-6">Study Statistics</h2>
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-6">
            {studyStats.map((stat, index) => {
              const IconComponent = stat.icon;
              return (
                <motion.div
                  key={stat.label}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.4 + index * 0.1, duration: 0.6 }}
                >
                  <Card className="glass-panel p-6 text-center space-y-3 glow-hover">
                    <IconComponent className="w-8 h-8 text-cyan-400 mx-auto" />
                    <div>
                      <p className="text-sm text-cyan-300">{stat.label}</p>
                      <p className="text-3xl text-white">
                        {stat.value}
                        <span className="text-lg text-cyan-400 ml-1">{stat.unit}</span>
                      </p>
                    </div>
                  </Card>
                </motion.div>
              );
            })}
          </div>
        </motion.div>

        {/* Future Predictions */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4, duration: 0.8 }}
        >
          <h2 className="text-2xl text-white mb-6">AI Predictions</h2>
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {predictions.map((prediction, index) => {
              const getTypeColor = (type: string) => {
                switch (type) {
                  case 'optimal': return 'text-cyan-400 border-cyan-500';
                  case 'learning': return 'text-purple-400 border-purple-500';
                  case 'warning': return 'text-orange-400 border-orange-500';
                  case 'success': return 'text-green-400 border-green-500';
                  default: return 'text-cyan-400 border-cyan-500';
                }
              };

              return (
                <motion.div
                  key={prediction.title}
                  initial={{ opacity: 0, x: index % 2 === 0 ? -20 : 20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: 0.6 + index * 0.1, duration: 0.6 }}
                >
                  <Card className={`glass-panel p-6 border-l-4 ${getTypeColor(prediction.type)} glow-hover`}>
                    <div className="space-y-3">
                      <div className="flex justify-between items-start">
                        <h3 className="text-lg text-white">{prediction.title}</h3>
                        <div className="text-right">
                          <p className={`text-sm ${getTypeColor(prediction.type).split(' ')[0]}`}>
                            {prediction.confidence}% confidence
                          </p>
                        </div>
                      </div>
                      <p className="text-cyan-300">{prediction.prediction}</p>
                      <div className="w-full bg-gray-700 rounded-full h-2">
                        <motion.div
                          className={`h-2 rounded-full ${getTypeColor(prediction.type).split(' ')[0].replace('text-', 'bg-')}`}
                          initial={{ width: 0 }}
                          animate={{ width: `${prediction.confidence}%` }}
                          transition={{ duration: 1, delay: 0.8 + index * 0.1 }}
                        />
                      </div>
                    </div>
                  </Card>
                </motion.div>
              );
            })}
          </div>
        </motion.div>

        {/* Weekly Progress Chart */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.6, duration: 0.8 }}
        >
          <h2 className="text-2xl text-white mb-6">Weekly Progress</h2>
          <Card className="glass-panel p-6">
            <div className="flex items-end justify-between h-32 space-x-2">
              {['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'].map((day, index) => {
                const height = [65, 80, 45, 90, 75, 30, 85][index];
                return (
                  <div key={day} className="flex flex-col items-center space-y-2 flex-1">
                    <motion.div
                      className="w-full bg-gradient-to-t from-cyan-500 to-purple-500 rounded-t-lg"
                      initial={{ height: 0 }}
                      animate={{ height: `${height}%` }}
                      transition={{ duration: 0.8, delay: 0.8 + index * 0.1 }}
                    />
                    <p className="text-xs text-cyan-300">{day}</p>
                  </div>
                );
              })}
            </div>
          </Card>
        </motion.div>
      </div>
    </div>
  );
}