import { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Card } from './ui/card';
import { Badge } from './ui/badge';
import { 
  User, 
  ArrowRight, 
  ArrowLeft,
  Brain,
  Zap,
  Skull,
  Gem,
  MessageSquare,
  BookOpen,
  Gift,
  Heart,
  Coffee,
  Music,
  Code,
  Palette,
  Gamepad2,
  Camera,
  Sparkles,
  Check
} from 'lucide-react';

interface ProfileSetupProps {
  onNext: (profile: ProfileData) => void;
}

export interface ProfileData {
  name: string;
  role: string;
  avatar: string;
  selectedRoles: string[];
  interests: string[];
  mood: string;
}

const avatarOptions = [
  "🤖", "👨‍💻", "👩‍💻", "🧠", "⚡", "🔮", "👤", "🎭",
  "🌟", "💎", "🔥", "❄️", "🌊", "⚛️", "🎯", "🚀"
];

const roleOptions = [
  {
    id: 'mentor',
    name: 'Mentor',
    description: 'Wise guidance and strategic advice',
    icon: Brain,
    gradient: 'from-cyan-500 to-blue-600'
  },
  {
    id: 'rival',
    name: 'Rival',
    description: 'Competitive challenger pushing limits',
    icon: Skull,
    gradient: 'from-red-500 to-orange-600'
  },
  {
    id: 'dark-twin',
    name: 'Dark Twin',
    description: 'Your shadow self with brutal honesty',
    icon: Skull,
    gradient: 'from-purple-900 to-black'
  },
  {
    id: 'future-predictor',
    name: 'Future Predictor',
    description: 'AI oracle revealing your potential',
    icon: Gem,
    gradient: 'from-pink-500 to-violet-600'
  }
];

const interestOptions = [
  { id: 'coding', name: 'Coding', icon: Code },
  { id: 'music', name: 'Music', icon: Music },
  { id: 'art', name: 'Art', icon: Palette },
  { id: 'gaming', name: 'Gaming', icon: Gamepad2 },
  { id: 'photography', name: 'Photography', icon: Camera },
  { id: 'coffee', name: 'Coffee', icon: Coffee },
  { id: 'fitness', name: 'Fitness', icon: Heart },
  { id: 'learning', name: 'Learning', icon: Brain }
];

const moodOptions = [
  { id: 'motivated', name: 'Motivated', emoji: '🔥', color: 'from-orange-400 to-red-500' },
  { id: 'curious', name: 'Curious', emoji: '🤔', color: 'from-blue-400 to-purple-500' },
  { id: 'creative', name: 'Creative', emoji: '🎨', color: 'from-pink-400 to-purple-500' },
  { id: 'focused', name: 'Focused', emoji: '🎯', color: 'from-green-400 to-blue-500' }
];

export function ProfileSetup({ onNext }: ProfileSetupProps) {
  const [currentStep, setCurrentStep] = useState(0);
  const [isCompleting, setIsCompleting] = useState(false);
  const [formData, setFormData] = useState({
    name: '',
    role: '',
    avatar: '🤖',
    selectedRoles: [] as string[],
    interests: [] as string[],
    mood: ''
  });

  const totalSteps = 3;
  const progress = ((currentStep + 1) / totalSteps) * 100;

  const handleInputChange = (field: string, value: string | string[]) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const toggleSelection = (field: 'selectedRoles' | 'interests', value: string) => {
    setFormData(prev => ({
      ...prev,
      [field]: prev[field].includes(value) 
        ? prev[field].filter(item => item !== value)
        : [...prev[field], value]
    }));
  };

  const nextStep = () => {
    if (currentStep < totalSteps - 1) {
      setCurrentStep(prev => prev + 1);
    } else {
      handleComplete();
    }
  };

  const prevStep = () => {
    if (currentStep > 0) {
      setCurrentStep(prev => prev - 1);
    }
  };

  const handleComplete = () => {
    setIsCompleting(true);
    setTimeout(() => {
      onNext(formData);
    }, 1500);
  };

  const isStepValid = () => {
    switch (currentStep) {
      case 0:
        return formData.name.trim() !== '' && formData.role.trim() !== '';
      case 1:
        return formData.selectedRoles.length > 0;
      case 2:
        return formData.interests.length > 0 && formData.mood !== '';
      default:
        return false;
    }
  };

  if (isCompleting) {
    return (
      <div className="min-h-screen starry-bg flex items-center justify-center p-4">
        <motion.div
          initial={{ scale: 0.5, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          transition={{ duration: 1, ease: "easeOut" }}
          className="text-center space-y-8 max-w-2xl mx-auto"
        >
          <motion.div
            animate={{ 
              rotate: [0, 360],
              scale: [1, 1.2, 1]
            }}
            transition={{ 
              rotate: { duration: 2, ease: "easeInOut" },
              scale: { duration: 1, repeat: Infinity, repeatType: "reverse" }
            }}
            className="relative mx-auto w-32 h-32"
          >
            <div className="absolute inset-0 neon-gradient rounded-full opacity-50 blur-xl animate-pulse"></div>
            <div className="relative text-8xl flex items-center justify-center w-full h-full bg-black/50 rounded-full border-4 border-cyan-400 glow-effect">
              {formData.avatar}
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.5, duration: 0.8 }}
          >
            <h1 className="text-6xl neon-gradient-text mb-4">TWIN ACTIVATED</h1>
            <p className="text-2xl text-cyan-300">
              Welcome to the digital realm, {formData.name}
            </p>
          </motion.div>
        </motion.div>
      </div>
    );
  }

  return (
    <div className="min-h-screen starry-bg p-4">
      <div className="max-w-6xl mx-auto">
        {/* Progress Bar */}
        <div className="mb-8 pt-4">
          <div className="max-w-2xl mx-auto">
            <div className="flex justify-between text-sm text-cyan-300 mb-2">
              <span>Step {currentStep + 1} of {totalSteps}</span>
              <span>{Math.round(progress)}% Complete</span>
            </div>
            <div className="w-full bg-black/30 rounded-full h-3 overflow-hidden">
              <div
                className="h-full neon-gradient rounded-full transition-all duration-500"
                style={{ width: `${progress}%` }}
              />
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Main Form Area */}
          <div className="lg:col-span-2">
            <AnimatePresence mode="wait">
              <motion.div
                key={currentStep}
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                transition={{ duration: 0.5, ease: "easeInOut" }}
              >
                {currentStep === 0 && (
                  <Card className="glass-panel p-8 space-y-8">
                    <div className="text-center space-y-4">
                      <h2 className="text-4xl neon-gradient-text">Digital Identity</h2>
                      <p className="text-xl text-cyan-300">Choose your name and avatar</p>
                    </div>

                    <div className="space-y-6">
                      <label className="block text-xl text-white">Choose Your Avatar</label>
                      <div className="grid grid-cols-8 gap-3">
                        {avatarOptions.map((avatar, index) => (
                          <button
                            key={index}
                            type="button"
                            onClick={() => handleInputChange('avatar', avatar)}
                            className={`p-4 rounded-2xl text-3xl transition-all duration-300 ${
                              formData.avatar === avatar
                                ? 'cyber-button glow-effect scale-110'
                                : 'bg-black/30 border border-cyan-500/20 hover:border-cyan-500/50'
                            }`}
                          >
                            {avatar}
                          </button>
                        ))}
                      </div>
                    </div>

                    <div className="space-y-4">
                      <label className="block text-xl text-white">Digital Name</label>
                      <div className="relative">
                        <User className="absolute left-4 top-1/2 transform -translate-y-1/2 w-6 h-6 text-cyan-400" />
                        <Input
                          type="text"
                          placeholder="Enter your name"
                          value={formData.name}
                          onChange={(e) => handleInputChange('name', e.target.value)}
                          className="pl-14 py-6 text-xl bg-black/30 border-cyan-500/30 text-white placeholder-cyan-300/50 focus:border-cyan-400 focus:ring-cyan-400/20"
                        />
                      </div>
                    </div>

                    <div className="space-y-4">
                      <label className="block text-xl text-white">Professional Role</label>
                      <Input
                        type="text"
                        placeholder="e.g., Student, Developer, Designer"
                        value={formData.role}
                        onChange={(e) => handleInputChange('role', e.target.value)}
                        className="py-6 text-xl bg-black/30 border-cyan-500/30 text-white placeholder-cyan-300/50 focus:border-cyan-400 focus:ring-cyan-400/20"
                      />
                    </div>
                  </Card>
                )}

                {currentStep === 1 && (
                  <Card className="glass-panel p-8 space-y-8">
                    <div className="text-center space-y-4">
                      <h2 className="text-4xl neon-gradient-text">AI Personalities</h2>
                      <p className="text-xl text-cyan-300">Select your doppelgänger's abilities</p>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      {roleOptions.map((role) => {
                        const IconComponent = role.icon;
                        const isSelected = formData.selectedRoles.includes(role.id);
                        
                        return (
                          <Card
                            key={role.id}
                            className={`p-6 cursor-pointer transition-all duration-300 ${
                              isSelected 
                                ? `bg-gradient-to-br ${role.gradient} border-2 border-white/50 glow-effect`
                                : 'glass-panel glow-hover border border-cyan-500/20'
                            }`}
                            onClick={() => toggleSelection('selectedRoles', role.id)}
                          >
                            <div className="space-y-4">
                              <div className="flex items-center justify-between">
                                <div className="flex items-center space-x-3">
                                  <div className={`p-3 rounded-full ${isSelected ? 'bg-white/20' : 'bg-black/30'}`}>
                                    <IconComponent className={`w-6 h-6 ${isSelected ? 'text-white' : 'text-cyan-400'}`} />
                                  </div>
                                  <h3 className="text-xl text-white">
                                    {role.name}
                                  </h3>
                                </div>
                                {isSelected && (
                                  <div className="w-6 h-6 bg-white rounded-full flex items-center justify-center">
                                    <Check className="w-4 h-4 text-green-600" />
                                  </div>
                                )}
                              </div>
                              <p className={`text-sm ${isSelected ? 'text-white/90' : 'text-cyan-300/80'}`}>
                                {role.description}
                              </p>
                            </div>
                          </Card>
                        );
                      })}
                    </div>
                  </Card>
                )}

                {currentStep === 2 && (
                  <Card className="glass-panel p-8 space-y-8">
                    <div className="text-center space-y-4">
                      <h2 className="text-4xl neon-gradient-text">Personalization</h2>
                      <p className="text-xl text-cyan-300">Your interests and current mood</p>
                    </div>

                    <div className="space-y-6">
                      <h3 className="text-2xl text-white">What interests you?</h3>
                      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                        {interestOptions.map((interest) => {
                          const IconComponent = interest.icon;
                          const isSelected = formData.interests.includes(interest.id);
                          
                          return (
                            <button
                              key={interest.id}
                              onClick={() => toggleSelection('interests', interest.id)}
                              className={`p-4 rounded-xl transition-all duration-300 ${
                                isSelected 
                                  ? 'cyber-button glow-effect scale-105' 
                                  : 'bg-black/30 border border-cyan-500/20 hover:border-cyan-500/50'
                              }`}
                            >
                              <div className="space-y-2 text-center">
                                <IconComponent className={`w-8 h-8 mx-auto ${isSelected ? 'text-cyan-400' : 'text-cyan-300'}`} />
                                <p className={`text-sm ${isSelected ? 'text-cyan-300' : 'text-white'}`}>
                                  {interest.name}
                                </p>
                              </div>
                            </button>
                          );
                        })}
                      </div>
                    </div>

                    <div className="space-y-6">
                      <h3 className="text-2xl text-white">What's your vibe?</h3>
                      <div className="grid grid-cols-2 md:grid-cols-2 gap-4">
                        {moodOptions.map((mood) => {
                          const isSelected = formData.mood === mood.id;
                          
                          return (
                            <button
                              key={mood.id}
                              onClick={() => handleInputChange('mood', mood.id)}
                              className={`p-6 rounded-xl transition-all duration-300 ${
                                isSelected 
                                  ? `bg-gradient-to-br ${mood.color} glow-effect scale-105 border-2 border-white/50` 
                                  : 'bg-black/30 border border-cyan-500/20 hover:border-cyan-500/50'
                              }`}
                            >
                              <div className="space-y-3 text-center">
                                <div className="text-4xl">{mood.emoji}</div>
                                <p className={`text-lg ${isSelected ? 'text-white' : 'text-cyan-300'}`}>
                                  {mood.name}
                                </p>
                              </div>
                            </button>
                          );
                        })}
                      </div>
                    </div>
                  </Card>
                )}
              </motion.div>
            </AnimatePresence>

            {/* Navigation */}
            <div className="flex justify-between mt-8">
              <Button
                onClick={prevStep}
                disabled={currentStep === 0}
                className="cyber-button text-cyan-300 px-6 py-3"
              >
                <ArrowLeft className="mr-2 w-5 h-5" />
                Previous
              </Button>
              <Button
                onClick={nextStep}
                disabled={!isStepValid()}
                className="cyber-button text-cyan-300 px-6 py-3 glow-hover disabled:opacity-50"
              >
                {currentStep === totalSteps - 1 ? (
                  <>
                    <Sparkles className="mr-2 w-5 h-5" />
                    Activate Twin
                  </>
                ) : (
                  <>
                    Next
                    <ArrowRight className="ml-2 w-5 h-5" />
                  </>
                )}
              </Button>
            </div>
          </div>

          {/* Live Preview */}
          <div className="lg:col-span-1">
            <div className="sticky top-8">
              <Card className="glass-panel p-6 space-y-6">
                <div className="text-center">
                  <h3 className="text-2xl neon-gradient-text mb-4">Live Preview</h3>
                  
                  <div className="relative w-24 h-24 mx-auto mb-4">
                    <div className="absolute inset-0 neon-gradient rounded-full opacity-30 blur-lg"></div>
                    <div className="relative text-6xl flex items-center justify-center w-full h-full bg-black/50 rounded-full border border-cyan-500/30">
                      {formData.avatar}
                    </div>
                  </div>

                  <div>
                    <h4 className="text-xl text-white">{formData.name || 'Your Name'}</h4>
                    <p className="text-cyan-300">{formData.role || 'Your Role'}</p>
                  </div>
                </div>

                {formData.selectedRoles.length > 0 && (
                  <div className="space-y-3">
                    <p className="text-sm text-cyan-300">AI Personalities:</p>
                    <div className="flex flex-wrap gap-2">
                      {formData.selectedRoles.map((roleId: string) => {
                        const role = roleOptions.find(r => r.id === roleId);
                        return role ? (
                          <Badge key={roleId} className="bg-cyan-500/20 text-cyan-300 border border-cyan-500/30">
                            {role.name}
                          </Badge>
                        ) : null;
                      })}
                    </div>
                  </div>
                )}

                {formData.interests.length > 0 && (
                  <div className="space-y-3">
                    <p className="text-sm text-cyan-300">Interests:</p>
                    <div className="flex flex-wrap gap-2">
                      {formData.interests.map((interestId: string) => {
                        const interest = interestOptions.find(i => i.id === interestId);
                        return interest ? (
                          <Badge key={interestId} className="bg-purple-500/20 text-purple-300 border border-purple-500/30">
                            {interest.name}
                          </Badge>
                        ) : null;
                      })}
                    </div>
                  </div>
                )}

                {formData.mood && (
                  <div className="space-y-3">
                    <p className="text-sm text-cyan-300">Current Vibe:</p>
                    <div className="text-center">
                      {(() => {
                        const mood = moodOptions.find(m => m.id === formData.mood);
                        return mood ? (
                          <div className={`inline-flex items-center space-x-2 px-4 py-2 rounded-full bg-gradient-to-r ${mood.color}`}>
                            <span className="text-2xl">{mood.emoji}</span>
                            <span className="text-white">{mood.name}</span>
                          </div>
                        ) : null;
                      })()}
                    </div>
                  </div>
                )}
              </Card>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}