import { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Card } from './ui/card';
import { Avatar } from './ui/avatar';
import { Badge } from './ui/badge';
import { ProfileData } from './ProfileSetup';
import { 
  Send, 
  ArrowLeft, 
  Brain, 
  Zap, 
  Skull, 
  MessageSquare,
  Users,
  Eye,
  Bot
} from 'lucide-react';

interface ChatScreenProps {
  profile: ProfileData;
  onBack: () => void;
}

interface Message {
  id: string;
  text: string;
  sender: 'user' | 'ai';
  timestamp: Date;
  mode?: string;
}

const modes = [
  { id: 'mentor', name: 'Mentor', icon: Brain, color: 'bg-cyan-500' },
  { id: 'motivator', name: 'Motivator', icon: Zap, color: 'bg-purple-500' },
  { id: 'rival', name: 'Dark Twin', icon: Skull, color: 'bg-red-500' },
  { id: 'roaster', name: 'Roaster', icon: MessageSquare, color: 'bg-orange-500' },
  { id: 'group', name: 'Group', icon: Users, color: 'bg-green-500' },
  { id: 'insights', name: 'Insights', icon: Eye, color: 'bg-indigo-500' }
];

const aiResponses = {
  mentor: [
    "I see great potential in you. Let's break this down step by step.",
    "Based on your learning patterns, I recommend focusing on foundational concepts first.",
    "Remember, every expert was once a beginner. You're making excellent progress.",
    "Here's a strategic approach that aligns with your goals..."
  ],
  motivator: [
    "🔥 YOU'VE GOT THIS! You're stronger than you realize!",
    "⚡ Every challenge is just your future success story in the making!",
    "🌟 I believe in you! Today is the day you level up!",
    "💎 You're not just learning, you're transforming into the best version of yourself!"
  ],
  rival: [
    "Is that really the best you can do? I expected more from you.",
    "Your past self would be disappointed in your current effort level.",
    "While you're making excuses, others are making progress. Choose wisely.",
    "Stop settling for mediocrity. You know you're capable of greatness."
  ],
  roaster: [
    "Oh, so NOW you want to study? After spending 3 hours on social media? 😏",
    "Let me guess, you're going to 'start tomorrow' again? Classic move!",
    "Your motivation is like WiFi - strong in theory, but keeps disconnecting when you need it most.",
    "I've seen glaciers move faster than your productivity today."
  ],
  group: [
    "The group is discussing quantum physics. Sarah's twin thinks you should join the debate!",
    "Mike's doppelgänger just solved that problem you've been stuck on. Want to collaborate?",
    "The collective IQ in this room just increased. Good thing you're here to balance it out! 😄",
    "Three minds working together... plus yours makes it interesting!"
  ],
  insights: [
    "I've analyzed your patterns. You're most productive between 2-4 PM on Tuesdays.",
    "Your stress levels spike when tackling mathematical concepts. Consider taking micro-breaks.",
    "Fascinating... your learning velocity increases 47% when classical music is playing.",
    "Hidden pattern detected: You perform best after consuming exactly 1.3 cups of coffee."
  ]
};

export function ChatScreen({ profile, onBack }: ChatScreenProps) {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: '1',
      text: `Hello ${profile.name}! Your digital doppelgänger is online. How can I assist you today?`,
      sender: 'ai',
      timestamp: new Date(),
      mode: 'mentor'
    }
  ]);
  const [inputText, setInputText] = useState('');
  const [currentMode, setCurrentMode] = useState('mentor');
  const [isTyping, setIsTyping] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const generateResponse = (userMessage: string, mode: string) => {
    const responses = aiResponses[mode as keyof typeof aiResponses] || aiResponses.mentor;
    return responses[Math.floor(Math.random() * responses.length)];
  };

  const handleSendMessage = async () => {
    if (!inputText.trim()) return;

    const userMessage: Message = {
      id: Date.now().toString(),
      text: inputText,
      sender: 'user',
      timestamp: new Date()
    };

    setMessages(prev => [...prev, userMessage]);
    setInputText('');
    setIsTyping(true);

    // Simulate AI thinking time
    setTimeout(() => {
      const aiMessage: Message = {
        id: (Date.now() + 1).toString(),
        text: generateResponse(inputText, currentMode),
        sender: 'ai',
        timestamp: new Date(),
        mode: currentMode
      };
      setMessages(prev => [...prev, aiMessage]);
      setIsTyping(false);
    }, 1000 + Math.random() * 2000);
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  return (
    <div className="min-h-screen starry-bg flex flex-col">
      {/* Header */}
      <motion.div
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
        className="glass-panel border-b border-cyan-500/20 p-4"
      >
        <div className="flex items-center justify-between max-w-4xl mx-auto">
          <div className="flex items-center space-x-4">
            <Button
              onClick={onBack}
              className="cyber-button p-2"
              size="sm"
            >
              <ArrowLeft className="w-5 h-5 text-cyan-400" />
            </Button>
            <div className="flex items-center space-x-3">
              <div className="relative">
                <div className="text-3xl">{profile.avatar}</div>
                <div className="absolute -bottom-1 -right-1 w-4 h-4 bg-green-400 rounded-full border-2 border-black animate-pulse"></div>
              </div>
              <div>
                <h2 className="text-xl text-white">Doppelgänger</h2>
                <p className="text-sm text-cyan-300">Online</p>
              </div>
            </div>
          </div>
          
          {/* AI Avatar */}
          <div className="relative">
            <motion.div
              animate={{ rotate: 360 }}
              transition={{ duration: 20, repeat: Infinity, ease: "linear" }}
              className="w-12 h-12 rounded-full border-2 border-cyan-400 flex items-center justify-center bg-black/50"
            >
              <Bot className="w-6 h-6 text-cyan-400" />
            </motion.div>
            <div className="absolute -top-1 -right-1 w-4 h-4 bg-cyan-400 rounded-full animate-pulse"></div>
          </div>
        </div>
      </motion.div>

      {/* Mode Selector */}
      <motion.div
        initial={{ opacity: 0, x: -20 }}
        animate={{ opacity: 1, x: 0 }}
        transition={{ delay: 0.2, duration: 0.5 }}
        className="p-4 max-w-4xl mx-auto w-full"
      >
        <div className="flex space-x-2 overflow-x-auto pb-2">
          {modes.map((mode) => {
            const IconComponent = mode.icon;
            return (
              <Button
                key={mode.id}
                onClick={() => setCurrentMode(mode.id)}
                className={`flex items-center space-x-2 px-4 py-2 rounded-full border transition-all duration-300 whitespace-nowrap ${
                  currentMode === mode.id
                    ? `${mode.color} text-white glow-effect`
                    : 'cyber-button text-cyan-300'
                }`}
                size="sm"
              >
                <IconComponent className="w-4 h-4" />
                <span>{mode.name}</span>
              </Button>
            );
          })}
        </div>
      </motion.div>

      {/* Messages */}
      <div className="flex-1 overflow-y-auto p-4 max-w-4xl mx-auto w-full">
        <AnimatePresence>
          {messages.map((message) => (
            <motion.div
              key={message.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              transition={{ duration: 0.3 }}
              className={`flex mb-4 ${message.sender === 'user' ? 'justify-end' : 'justify-start'}`}
            >
              <div className={`flex items-end space-x-2 max-w-xs lg:max-w-md ${
                message.sender === 'user' ? 'flex-row-reverse space-x-reverse' : ''
              }`}>
                {message.sender === 'ai' && (
                  <div className="text-2xl">{profile.avatar}</div>
                )}
                <Card className={`p-4 ${
                  message.sender === 'user'
                    ? 'cyber-button text-cyan-300'
                    : 'glass-panel text-white'
                }`}>
                  <p className="text-sm leading-relaxed">{message.text}</p>
                  {message.mode && (
                    <Badge className={`mt-2 text-xs ${modes.find(m => m.id === message.mode)?.color} text-white`}>
                      {modes.find(m => m.id === message.mode)?.name}
                    </Badge>
                  )}
                </Card>
                {message.sender === 'user' && (
                  <div className="text-2xl">👤</div>
                )}
              </div>
            </motion.div>
          ))}
        </AnimatePresence>

        {/* Typing Indicator */}
        {isTyping && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="flex items-end space-x-2 mb-4"
          >
            <div className="text-2xl">{profile.avatar}</div>
            <Card className="glass-panel p-4">
              <div className="flex space-x-1">
                {[...Array(3)].map((_, i) => (
                  <motion.div
                    key={i}
                    animate={{ opacity: [0.4, 1, 0.4] }}
                    transition={{ 
                      duration: 1, 
                      repeat: Infinity, 
                      delay: i * 0.2 
                    }}
                    className="w-2 h-2 bg-cyan-400 rounded-full"
                  />
                ))}
              </div>
            </Card>
          </motion.div>
        )}
        <div ref={messagesEndRef} />
      </div>

      {/* Input */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.3, duration: 0.5 }}
        className="glass-panel border-t border-cyan-500/20 p-4"
      >
        <div className="flex space-x-4 max-w-4xl mx-auto">
          <Input
            value={inputText}
            onChange={(e) => setInputText(e.target.value)}
            onKeyPress={handleKeyPress}
            placeholder="Message your doppelgänger..."
            className="flex-1 bg-black/30 border-cyan-500/30 text-white placeholder-cyan-300/50 focus:border-cyan-400 focus:ring-cyan-400/20"
            disabled={isTyping}
          />
          <Button
            onClick={handleSendMessage}
            disabled={!inputText.trim() || isTyping}
            className="cyber-button px-6"
          >
            <Send className="w-5 h-5 text-cyan-400" />
          </Button>
        </div>
      </motion.div>
    </div>
  );
}