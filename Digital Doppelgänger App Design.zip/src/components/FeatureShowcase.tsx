import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Button } from './ui/button';
import { Card } from './ui/card';
import { 
  Brain, 
  Zap, 
  Gem, 
  Skull, 
  MessageSquare, 
  Users, 
  Eye, 
  Gift,
  ChevronLeft,
  ChevronRight,
  ArrowRight
} from 'lucide-react';

interface FeatureShowcaseProps {
  onNext: () => void;
}

const features = [
  {
    icon: Brain,
    title: "Personalized Learning",
    description: "AI adapts to your learning style and creates custom study paths just for you.",
    color: "text-cyan-400"
  },
  {
    icon: Zap,
    title: "Motivation Booster",
    description: "Get pumped with personalized affirmations and achievement celebrations.",
    color: "text-purple-400"
  },
  {
    icon: Gem,
    title: "Future Predictor",
    description: "AI analyzes your patterns to predict and optimize your future performance.",
    color: "text-pink-400"
  },
  {
    icon: Skull,
    title: "Dark Twin Rival",
    description: "Your evil twin challenges you to push harder and break your limits.",
    color: "text-red-400"
  },
  {
    icon: MessageSquare,
    title: "Roasting + Reality Check",
    description: "Brutally honest feedback to keep you grounded and focused on reality.",
    color: "text-orange-400"
  },
  {
    icon: Users,
    title: "Group Doppelgänger",
    description: "Study with friends and their AI twins in collaborative virtual sessions.",
    color: "text-green-400"
  },
  {
    icon: Eye,
    title: "Shadow Insights",
    description: "Deep analytics into your hidden patterns and unconscious behaviors.",
    color: "text-indigo-400"
  },
  {
    icon: Gift,
    title: "Surprise Extras",
    description: "Hidden features and easter eggs that unlock as you progress.",
    color: "text-yellow-400"
  }
];

export function FeatureShowcase({ onNext }: FeatureShowcaseProps) {
  const [currentSlide, setCurrentSlide] = useState(0);
  const [isAutoPlaying, setIsAutoPlaying] = useState(true);

  const featuresPerSlide = 4;
  const totalSlides = Math.ceil(features.length / featuresPerSlide);

  useEffect(() => {
    if (!isAutoPlaying) return;

    const interval = setInterval(() => {
      setCurrentSlide((prev) => (prev + 1) % totalSlides);
    }, 5000);

    return () => clearInterval(interval);
  }, [isAutoPlaying, totalSlides]);

  const getCurrentFeatures = () => {
    const start = currentSlide * featuresPerSlide;
    return features.slice(start, start + featuresPerSlide);
  };

  const nextSlide = () => {
    setIsAutoPlaying(false);
    setCurrentSlide((prev) => (prev + 1) % totalSlides);
  };

  const prevSlide = () => {
    setIsAutoPlaying(false);
    setCurrentSlide((prev) => (prev - 1 + totalSlides) % totalSlides);
  };

  return (
    <div className="min-h-screen starry-bg flex flex-col items-center justify-center p-4">
      <motion.div
        initial={{ opacity: 0, y: 30 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.8 }}
        className="w-full max-w-6xl mx-auto"
      >
        {/* Header */}
        <div className="text-center mb-12">
          <h2 className="text-5xl md:text-6xl neon-gradient-text mb-4">
            CAPABILITIES
          </h2>
          <p className="text-xl text-cyan-300">
            Unleash the power of your digital twin
          </p>
        </div>

        {/* Feature Cards */}
        <div className="relative mb-8">
          <AnimatePresence mode="wait">
            <motion.div
              key={currentSlide}
              initial={{ opacity: 0, x: 100 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -100 }}
              transition={{ duration: 0.5, ease: "easeInOut" }}
              className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6"
            >
              {getCurrentFeatures().map((feature, index) => {
                const IconComponent = feature.icon;
                return (
                  <motion.div
                    key={`${currentSlide}-${index}`}
                    initial={{ opacity: 0, y: 50 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: index * 0.1, duration: 0.6 }}
                  >
                    <Card className="glass-panel p-6 h-full glow-hover cursor-pointer group">
                      <div className="text-center space-y-4">
                        <div className="mx-auto w-16 h-16 rounded-full bg-black/30 flex items-center justify-center group-hover:glow-effect transition-all duration-300">
                          <IconComponent className={`w-8 h-8 ${feature.color}`} />
                        </div>
                        <h3 className="text-xl text-white group-hover:neon-gradient-text transition-all duration-300">
                          {feature.title}
                        </h3>
                        <p className="text-sm text-cyan-300/80 leading-relaxed">
                          {feature.description}
                        </p>
                      </div>
                    </Card>
                  </motion.div>
                );
              })}
            </motion.div>
          </AnimatePresence>

          {/* Navigation Arrows */}
          <Button
            onClick={prevSlide}
            className="absolute left-0 top-1/2 -translate-y-1/2 -translate-x-12 cyber-button p-3"
            disabled={currentSlide === 0}
          >
            <ChevronLeft className="w-6 h-6 text-cyan-400" />
          </Button>
          <Button
            onClick={nextSlide}
            className="absolute right-0 top-1/2 -translate-y-1/2 translate-x-12 cyber-button p-3"
            disabled={currentSlide === totalSlides - 1}
          >
            <ChevronRight className="w-6 h-6 text-cyan-400" />
          </Button>
        </div>

        {/* Slide Indicators */}
        <div className="flex justify-center space-x-2 mb-12">
          {Array.from({ length: totalSlides }).map((_, index) => (
            <button
              key={index}
              onClick={() => {
                setIsAutoPlaying(false);
                setCurrentSlide(index);
              }}
              className={`w-3 h-3 rounded-full transition-all duration-300 ${
                index === currentSlide 
                  ? 'bg-cyan-400 glow-effect' 
                  : 'bg-cyan-400/30 hover:bg-cyan-400/60'
              }`}
            />
          ))}
        </div>

        {/* Continue Button */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 1, duration: 0.8 }}
          className="text-center"
        >
          <Button
            onClick={onNext}
            className="cyber-button text-xl px-12 py-6 rounded-2xl glow-hover text-cyan-300 border-2"
            size="lg"
          >
            Continue Journey
            <ArrowRight className="ml-3 w-6 h-6" />
          </Button>
        </motion.div>
      </motion.div>
    </div>
  );
}