import { motion } from 'motion/react';
import { Button } from './ui/button';
import { Card } from './ui/card';
import { ProfileData } from './ProfileSetup';
import { 
  MessageCircle, 
  BarChart3, 
  Settings, 
  ArrowRight,
  Sparkles
} from 'lucide-react';

interface HomeScreenProps {
  profile: ProfileData;
  onNavigate: (screen: string) => void;
}

export function HomeScreen({ profile, onNavigate }: HomeScreenProps) {
  const quickAccessItems = [
    {
      title: "Chat",
      description: "Talk with your AI twin",
      icon: MessageCircle,
      color: "text-cyan-400",
      action: () => onNavigate('chat')
    },
    {
      title: "Dashboard",
      description: "View your insights",
      icon: BarChart3,
      color: "text-purple-400",
      action: () => onNavigate('dashboard')
    },
    {
      title: "Settings",
      description: "Control your twin",
      icon: Settings,
      color: "text-pink-400",
      action: () => onNavigate('settings')
    }
  ];

  return (
    <div className="min-h-screen starry-bg p-4">
      <div className="max-w-4xl mx-auto pt-8">
        {/* Welcome Section */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          className="text-center mb-12"
        >
          {/* Profile Avatar */}
          <motion.div
            animate={{ 
              scale: [1, 1.1, 1],
              rotate: [0, 5, -5, 0]
            }}
            transition={{ 
              scale: { duration: 2, repeat: Infinity, ease: "easeInOut" },
              rotate: { duration: 4, repeat: Infinity, ease: "easeInOut" }
            }}
            className="relative mx-auto w-24 h-24 mb-6"
          >
            <div className="absolute inset-0 neon-gradient rounded-full opacity-30 blur-lg"></div>
            <div className="relative text-6xl flex items-center justify-center w-full h-full bg-black/50 rounded-full border border-cyan-500/30">
              {profile.avatar}
            </div>
          </motion.div>

          {/* Welcome Message */}
          <h1 className="text-4xl md:text-5xl neon-gradient-text mb-4">
            Welcome, {profile.name}
          </h1>
          <p className="text-xl text-cyan-300 mb-2">
            {profile.role}
          </p>
          <p className="text-lg text-cyan-300/70">
            Your digital doppelgänger is ready
          </p>
        </motion.div>

        {/* Main Action */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3, duration: 0.8 }}
          className="text-center mb-12"
        >
          <Button
            onClick={() => onNavigate('chat')}
            className="cyber-button text-2xl px-16 py-8 rounded-3xl glow-hover text-cyan-300 border-2"
            size="lg"
          >
            <Sparkles className="mr-4 w-8 h-8" />
            Continue Journey
            <ArrowRight className="ml-4 w-8 h-8" />
          </Button>
        </motion.div>

        {/* Quick Access Cards */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.6, duration: 0.8 }}
          className="space-y-6"
        >
          <h2 className="text-2xl text-center text-white mb-8">Quick Access</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {quickAccessItems.map((item, index) => {
              const IconComponent = item.icon;
              return (
                <motion.div
                  key={item.title}
                  initial={{ opacity: 0, y: 50 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.8 + index * 0.1, duration: 0.6 }}
                >
                  <Card
                    className="glass-panel p-6 glow-hover cursor-pointer group transition-all duration-300"
                    onClick={item.action}
                  >
                    <div className="text-center space-y-4">
                      <div className="mx-auto w-16 h-16 rounded-full bg-black/30 flex items-center justify-center group-hover:glow-effect transition-all duration-300">
                        <IconComponent className={`w-8 h-8 ${item.color}`} />
                      </div>
                      <div>
                        <h3 className="text-xl text-white group-hover:neon-gradient-text transition-all duration-300">
                          {item.title}
                        </h3>
                        <p className="text-cyan-300/80 mt-2">
                          {item.description}
                        </p>
                      </div>
                    </div>
                  </Card>
                </motion.div>
              );
            })}
          </div>
        </motion.div>

        {/* Floating Elements */}
        <div className="fixed inset-0 pointer-events-none overflow-hidden">
          {[...Array(8)].map((_, i) => (
            <motion.div
              key={i}
              className="absolute w-1 h-1 bg-cyan-400 rounded-full opacity-40"
              style={{
                left: `${Math.random() * 100}%`,
                top: `${Math.random() * 100}%`,
              }}
              animate={{
                scale: [0, 1, 0],
                opacity: [0, 1, 0],
              }}
              transition={{
                duration: 2 + Math.random() * 2,
                repeat: Infinity,
                delay: Math.random() * 2,
                ease: "easeInOut",
              }}
            />
          ))}
        </div>
      </div>
    </div>
  );
}