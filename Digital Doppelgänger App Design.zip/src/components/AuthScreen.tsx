import { useState } from 'react';
import { motion } from 'motion/react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Card } from './ui/card';
import { User, Mail, Lock, ArrowRight } from 'lucide-react';

interface AuthScreenProps {
  onNext: () => void;
}

export function AuthScreen({ onNext }: AuthScreenProps) {
  const [isLogin, setIsLogin] = useState(true);
  const [formData, setFormData] = useState({
    email: '',
    password: '',
    name: ''
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onNext();
  };

  const handleInputChange = (field: string, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  return (
    <div className="min-h-screen starry-bg flex items-center justify-center p-4">
      <motion.div
        initial={{ opacity: 0, y: 50 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.8, ease: "easeOut" }}
        className="w-full max-w-md"
      >
        <div className="relative perspective-1000">
          <motion.div
            initial={false}
            animate={{ rotateY: isLogin ? 0 : 180 }}
            transition={{ duration: 0.8, type: "spring" }}
            className="relative preserve-3d"
          >
            {/* Login Card */}
            <Card className={`glass-panel p-8 space-y-6 backface-hidden ${!isLogin ? 'opacity-0' : ''}`}>
              <div className="text-center space-y-2">
                <h2 className="text-3xl neon-gradient-text">Welcome Back</h2>
                <p className="text-cyan-300">Enter the digital realm</p>
              </div>

              <form onSubmit={handleSubmit} className="space-y-4">
                <div className="relative">
                  <Mail className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-cyan-400" />
                  <Input
                    type="email"
                    placeholder="Enter your email"
                    value={formData.email}
                    onChange={(e) => handleInputChange('email', e.target.value)}
                    className="pl-12 bg-black/30 border-cyan-500/30 text-white placeholder-cyan-300/50 focus:border-cyan-400 focus:ring-cyan-400/20"
                  />
                </div>

                <div className="relative">
                  <Lock className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-cyan-400" />
                  <Input
                    type="password"
                    placeholder="Enter your password"
                    value={formData.password}
                    onChange={(e) => handleInputChange('password', e.target.value)}
                    className="pl-12 bg-black/30 border-cyan-500/30 text-white placeholder-cyan-300/50 focus:border-cyan-400 focus:ring-cyan-400/20"
                  />
                </div>

                <Button
                  type="submit"
                  className="w-full cyber-button text-cyan-300 py-6 text-lg"
                >
                  Access Portal
                  <ArrowRight className="ml-2 w-5 h-5" />
                </Button>
              </form>

              <div className="text-center">
                <button
                  onClick={() => setIsLogin(false)}
                  className="text-cyan-400 hover:text-cyan-300 transition-colors"
                >
                  New here? Create your digital twin →
                </button>
              </div>
            </Card>

            {/* Signup Card */}
            <Card className={`glass-panel p-8 space-y-6 absolute inset-0 backface-hidden rotate-y-180 ${isLogin ? 'opacity-0' : ''}`}>
              <div className="text-center space-y-2">
                <h2 className="text-3xl neon-gradient-text">Join the Matrix</h2>
                <p className="text-cyan-300">Create your digital identity</p>
              </div>

              <form onSubmit={handleSubmit} className="space-y-4">
                <div className="relative">
                  <User className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-cyan-400" />
                  <Input
                    type="text"
                    placeholder="Choose your name"
                    value={formData.name}
                    onChange={(e) => handleInputChange('name', e.target.value)}
                    className="pl-12 bg-black/30 border-cyan-500/30 text-white placeholder-cyan-300/50 focus:border-cyan-400 focus:ring-cyan-400/20"
                  />
                </div>

                <div className="relative">
                  <Mail className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-cyan-400" />
                  <Input
                    type="email"
                    placeholder="Enter your email"
                    value={formData.email}
                    onChange={(e) => handleInputChange('email', e.target.value)}
                    className="pl-12 bg-black/30 border-cyan-500/30 text-white placeholder-cyan-300/50 focus:border-cyan-400 focus:ring-cyan-400/20"
                  />
                </div>

                <div className="relative">
                  <Lock className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-cyan-400" />
                  <Input
                    type="password"
                    placeholder="Create secure password"
                    value={formData.password}
                    onChange={(e) => handleInputChange('password', e.target.value)}
                    className="pl-12 bg-black/30 border-cyan-500/30 text-white placeholder-cyan-300/50 focus:border-cyan-400 focus:ring-cyan-400/20"
                  />
                </div>

                <Button
                  type="submit"
                  className="w-full cyber-button text-cyan-300 py-6 text-lg"
                >
                  Initialize Twin
                  <ArrowRight className="ml-2 w-5 h-5" />
                </Button>
              </form>

              <div className="text-center">
                <button
                  onClick={() => setIsLogin(true)}
                  className="text-cyan-400 hover:text-cyan-300 transition-colors"
                >
                  Already have a twin? Sign in →
                </button>
              </div>
            </Card>
          </motion.div>
        </div>
      </motion.div>
    </div>
  );
}