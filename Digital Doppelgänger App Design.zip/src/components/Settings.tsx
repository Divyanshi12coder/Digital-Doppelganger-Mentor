import { useState } from 'react';
import { motion } from 'motion/react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Card } from './ui/card';
import { Switch } from './ui/switch';
import { ProfileData } from './ProfileSetup';
import { 
  ArrowLeft, 
  User, 
  Briefcase, 
  Bell, 
  Shield, 
  Palette, 
  Volume2,
  LogOut,
  Settings as SettingsIcon
} from 'lucide-react';

interface SettingsProps {
  profile: ProfileData;
  onBack: () => void;
  onLogout: () => void;
  onUpdateProfile: (profile: ProfileData) => void;
}

const avatarOptions = [
  "🤖", "👨‍💻", "👩‍💻", "🧠", "⚡", "🔮", "👤", "🎭",
  "🌟", "💎", "🔥", "❄️", "🌊", "⚛️", "🎯", "🚀"
];

export function Settings({ profile, onBack, onLogout, onUpdateProfile }: SettingsProps) {
  const [editedProfile, setEditedProfile] = useState(profile);
  const [settings, setSettings] = useState({
    notifications: true,
    soundEffects: true,
    darkMode: true,
    autoSave: true,
    aiPersonality: 'adaptive'
  });

  const handleProfileUpdate = () => {
    onUpdateProfile(editedProfile);
  };

  const handleInputChange = (field: string, value: string) => {
    setEditedProfile(prev => ({ ...prev, [field]: value }));
  };

  const handleSettingToggle = (setting: string) => {
    setSettings(prev => ({ ...prev, [setting]: !prev[setting as keyof typeof prev] }));
  };

  const settingsSections = [
    {
      title: "Profile Settings",
      icon: User,
      content: (
        <div className="space-y-6">
          {/* Avatar Selection */}
          <div className="space-y-3">
            <label className="block text-white">Avatar</label>
            <div className="grid grid-cols-8 gap-2">
              {avatarOptions.map((avatar, index) => (
                <motion.button
                  key={index}
                  type="button"
                  onClick={() => handleInputChange('avatar', avatar)}
                  className={`p-3 rounded-xl text-2xl transition-all duration-300 ${
                    editedProfile.avatar === avatar
                      ? 'cyber-button glow-effect scale-110'
                      : 'bg-black/30 border border-cyan-500/20 hover:border-cyan-500/50'
                  }`}
                  whileHover={{ scale: 1.1 }}
                  whileTap={{ scale: 0.95 }}
                >
                  {avatar}
                </motion.button>
              ))}
            </div>
          </div>

          {/* Name Input */}
          <div className="space-y-2">
            <label className="block text-white">Name</label>
            <div className="relative">
              <User className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-cyan-400" />
              <Input
                type="text"
                value={editedProfile.name}
                onChange={(e) => handleInputChange('name', e.target.value)}
                className="pl-10 bg-black/30 border-cyan-500/30 text-white focus:border-cyan-400"
              />
            </div>
          </div>

          {/* Role Input */}
          <div className="space-y-2">
            <label className="block text-white">Role</label>
            <div className="relative">
              <Briefcase className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-cyan-400" />
              <Input
                type="text"
                value={editedProfile.role}
                onChange={(e) => handleInputChange('role', e.target.value)}
                className="pl-10 bg-black/30 border-cyan-500/30 text-white focus:border-cyan-400"
              />
            </div>
          </div>

          <Button
            onClick={handleProfileUpdate}
            className="cyber-button text-cyan-300 w-full"
          >
            Update Profile
          </Button>
        </div>
      )
    },
    {
      title: "Notifications",
      icon: Bell,
      content: (
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-white">Push Notifications</p>
              <p className="text-sm text-cyan-300/70">Get notified about important updates</p>
            </div>
            <Switch
              checked={settings.notifications}
              onCheckedChange={() => handleSettingToggle('notifications')}
            />
          </div>
          <div className="flex items-center justify-between">
            <div>
              <p className="text-white">Sound Effects</p>
              <p className="text-sm text-cyan-300/70">Play sounds for interactions</p>
            </div>
            <Switch
              checked={settings.soundEffects}
              onCheckedChange={() => handleSettingToggle('soundEffects')}
            />
          </div>
        </div>
      )
    },
    {
      title: "AI Behavior",
      icon: Shield,
      content: (
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-white">Auto-Save Progress</p>
              <p className="text-sm text-cyan-300/70">Automatically save your progress</p>
            </div>
            <Switch
              checked={settings.autoSave}
              onCheckedChange={() => handleSettingToggle('autoSave')}
            />
          </div>
          <div className="space-y-2">
            <label className="block text-white">AI Personality</label>
            <select 
              value={settings.aiPersonality}
              onChange={(e) => setSettings(prev => ({ ...prev, aiPersonality: e.target.value }))}
              className="w-full p-3 bg-black/30 border border-cyan-500/30 rounded-lg text-white focus:border-cyan-400"
            >
              <option value="adaptive">Adaptive</option>
              <option value="supportive">Supportive</option>
              <option value="challenging">Challenging</option>
              <option value="analytical">Analytical</option>
            </select>
          </div>
        </div>
      )
    }
  ];

  return (
    <div className="min-h-screen starry-bg">
      {/* Header */}
      <motion.div
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
        className="glass-panel border-b border-cyan-500/20 p-4"
      >
        <div className="flex items-center justify-between max-w-4xl mx-auto">
          <div className="flex items-center space-x-4">
            <Button
              onClick={onBack}
              className="cyber-button p-2"
              size="sm"
            >
              <ArrowLeft className="w-5 h-5 text-cyan-400" />
            </Button>
            <div className="flex items-center space-x-3">
              <SettingsIcon className="w-8 h-8 text-cyan-400" />
              <div>
                <h1 className="text-2xl neon-gradient-text">Control Room</h1>
                <p className="text-cyan-300">Customize your digital twin</p>
              </div>
            </div>
          </div>
          <div className="flex items-center space-x-3">
            <div className="text-3xl">{profile.avatar}</div>
          </div>
        </div>
      </motion.div>

      <div className="max-w-4xl mx-auto p-6 space-y-8">
        {/* Settings Sections */}
        {settingsSections.map((section, index) => {
          const IconComponent = section.icon;
          return (
            <motion.div
              key={section.title}
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1, duration: 0.6 }}
            >
              <Card className="glass-panel p-6 space-y-4">
                <div className="flex items-center space-x-3 mb-4">
                  <IconComponent className="w-6 h-6 text-cyan-400" />
                  <h2 className="text-xl text-white">{section.title}</h2>
                </div>
                {section.content}
              </Card>
            </motion.div>
          );
        })}

        {/* Danger Zone */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4, duration: 0.6 }}
        >
          <Card className="glass-panel p-6 border border-red-500/30">
            <div className="flex items-center space-x-3 mb-4">
              <LogOut className="w-6 h-6 text-red-400" />
              <h2 className="text-xl text-white">Danger Zone</h2>
            </div>
            <p className="text-red-300/80 mb-6">
              Logout will disconnect your digital twin and return you to the void.
            </p>
            <Button
              onClick={onLogout}
              className="bg-red-500/20 border-2 border-red-500 text-red-300 hover:bg-red-500/30 hover:border-red-400 transition-all duration-300 glow-hover px-8 py-4 text-lg"
            >
              <LogOut className="mr-3 w-6 h-6" />
              Logout & Return to Void
            </Button>
          </Card>
        </motion.div>
      </div>
    </div>
  );
}