import { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { WelcomeScreen } from './components/WelcomeScreen';
import { AuthScreen } from './components/AuthScreen';
import { FeatureShowcase } from './components/FeatureShowcase';
import { ProfileSetup, ProfileData } from './components/ProfileSetup';
import { HomeScreen } from './components/HomeScreen';
import { ChatScreen } from './components/ChatScreen';
import { Dashboard } from './components/Dashboard';
import { Settings } from './components/Settings';

type Screen = 'welcome' | 'auth' | 'features' | 'profile' | 'home' | 'chat' | 'dashboard' | 'settings';

export default function App() {
  const [currentScreen, setCurrentScreen] = useState<Screen>('welcome');
  const [profile, setProfile] = useState<ProfileData | null>(null);

  const handleProfileSetup = (profileData: ProfileData) => {
    setProfile(profileData);
    setCurrentScreen('home');
  };

  const handleNavigation = (screen: string) => {
    setCurrentScreen(screen as Screen);
  };

  const handleLogout = () => {
    setProfile(null);
    setCurrentScreen('welcome');
  };

  const handleUpdateProfile = (updatedProfile: ProfileData) => {
    setProfile(updatedProfile);
  };

  const renderScreen = () => {
    switch (currentScreen) {
      case 'welcome':
        return <WelcomeScreen onNext={() => setCurrentScreen('auth')} />;
      case 'auth':
        return <AuthScreen onNext={() => setCurrentScreen('features')} />;
      case 'features':
        return <FeatureShowcase onNext={() => setCurrentScreen('profile')} />;
      case 'profile':
        return <ProfileSetup onNext={handleProfileSetup} />;
      case 'home':
        return profile ? (
          <HomeScreen 
            profile={profile} 
            onNavigate={handleNavigation}
          />
        ) : null;
      case 'chat':
        return profile ? (
          <ChatScreen 
            profile={profile} 
            onBack={() => setCurrentScreen('home')}
          />
        ) : null;
      case 'dashboard':
        return profile ? (
          <Dashboard 
            profile={profile} 
            onBack={() => setCurrentScreen('home')}
          />
        ) : null;
      case 'settings':
        return profile ? (
          <Settings 
            profile={profile} 
            onBack={() => setCurrentScreen('home')}
            onLogout={handleLogout}
            onUpdateProfile={handleUpdateProfile}
          />
        ) : null;
      default:
        return <WelcomeScreen onNext={() => setCurrentScreen('auth')} />;
    }
  };

  return (
    <div className="min-h-screen bg-black overflow-hidden">
      <AnimatePresence mode="wait">
        <motion.div
          key={currentScreen}
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.5, ease: "easeInOut" }}
          className="min-h-screen"
        >
          {renderScreen()}
        </motion.div>
      </AnimatePresence>
    </div>
  );
}