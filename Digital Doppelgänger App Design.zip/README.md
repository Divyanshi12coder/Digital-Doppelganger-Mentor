
  # Digital Doppelgänger App Design

  This is a code bundle for Digital Doppelgänger App Design. The original project is available at https://www.figma.com/design/0iGRZt3zgE0DOyVaSg1DiM/Digital-Doppelg%C3%A4nger-App-Design.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  